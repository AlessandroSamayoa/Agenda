﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Agenda
{
    class Agenda
    {
        int numID=100;

        public  void agenda(ArrayList id ,ArrayList nombre,ArrayList apellido,ArrayList telefono,ArrayList email )
        {
            //Declaracion de Arbol
            AVL tree = new AVL();
            //Variables
            string ingNombre = "";
            string ingApellido = "";
            string correo = "";
            int num;
            //Generar ID Automatico
            numID = numID + 1;
            tree.Insertar(numID);
            id.Add(numID);


            //Ingresar nombre
            Console.WriteLine("Ingrese un nombre");
            ingNombre = Console.ReadLine();
            nombre.Add(ingNombre);
            //Ingresar apellido
            Console.WriteLine("Ingrese apellido");
            ingApellido = Console.ReadLine();
            apellido.Add(ingApellido);
            //IngresarNum
            Console.WriteLine("Ingrese un num telefonico");
            num = int.Parse(Console.ReadLine());
            telefono.Add(num);
            Console.WriteLine("Ingrese una dirreccion de correo");
            //Ingresar Correo
            correo = Console.ReadLine();
            email.Add(correo);



        }
        public void mostrar(ArrayList id, ArrayList nombre, ArrayList apellido, ArrayList telefono, ArrayList email)
        {
          
            for (int i = 0; i < nombre.Count; i++)
            {
                Console.WriteLine(id[i]+"\t"+nombre[i] + "\t" + apellido[i] + "\t" + telefono[i] + "\t" + email[i]);
            }

        }
        public void buscar(ArrayList id, ArrayList nombre, ArrayList apellido, ArrayList telefono, ArrayList email)
        {
            //Declaracion de Arbol
            AVL tree = new AVL();
            //variables
            int index,rango;
            Console.WriteLine("Ingrese el id ");
            index = int.Parse(Console.ReadLine());
            rango = id.IndexOf(index);
            Console.WriteLine("Nombre\t\tApellido\ttelefono\tEmail");
            Console.WriteLine(nombre[rango]+"\t\t"+apellido[rango]+"\t"+telefono[rango]+"\t\t"+email[rango]);
            tree.BuscarValor(index);



        }
        public void menu()
        {
            Console.WriteLine("1. Ingresar ");
            Console.WriteLine("2. Buscar ");
            Console.WriteLine("3. Modificar");
            Console.WriteLine("4. Eliminar");
            Console.WriteLine("5. Salir");
            Console.Write("Selecione una opcion :");

        }
    }
}
